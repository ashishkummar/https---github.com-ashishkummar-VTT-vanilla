{
  "products": [
    {
      "deal": "$1<sup>88</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43gfe51otm1qot1v5o18ph10.jpg",
      "description": "24 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Prego Traditional Italian Sauce",
      "sku": 9213131,
	  "rollback": "true"
    },
    {
      "deal": "$1<sup></sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43g1tg9tbtskc15stasks.jpg",
      "description": "5.7 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Knorr Rice Sides Cheddar Broccoli",
      "sku": 9274649,
      "rollback": "true"
    },
    {
      "deal": "$5<sup>88</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43e1pdr1bq9rdr1kee55gf.jpg",
      "description": "30.4 oz., 36 ct.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Quaker Chewy Chocolate Chip Granola Bars",
      "sku": 568318662,
      "rollback": "true"
    },
    {
      "deal": "$3<sup>88</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e64f4ni619r1agagni1lb21i0c3.jpg",
      "description": "24 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Hidden Valley Original Ranch Dressing",
      "sku": 573918546,
      "rollback": "true"
    },
    {
      "deal": "$1<sup>44</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43ftuv9m411ch1c909sqp.jpg",
      "description": "5.2 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Pringles Original Potato Crisps",
      "sku": 570377496,
      "rollback": "true"
    },
    {
      "deal": "$6<sup>92</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43mlhg1mqr3es17jj96a2a.jpg",
      "description": "32 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Marketside Triple Chocolate Cake",
      "sku": 567446552,
      "rollback": "true"
    },
    {
      "deal": "$5<sup>98</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e5vp3usv1gc9rno1h2q1e71a865.jpg",
      "description": "22.35 oz., 30 ct.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Nature Valley Crunchy Granola Bars",
      "sku": 577497303,
      "rollback": "true"
    },
    {
      "deal": "$1<sup>98</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43d7dv6crdn81rgdksna.jpg",
      "description": "128 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Hawaiian Punch Fruit Punch",
      "sku": 9287163,
      "rollback": "true"
    },
    {
      "deal": "$5<sup>74</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43g19on1hma1tac1og21pva11.jpg",
      "description": "20 oz., 10 ct.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Smucker's Uncrustables Sandwiches",
      "sku": 550527320,
      "rollback": "true"
    },
    {
      "deal": "$3<sup>98</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43i10ne115m11344bi1s3q1c.jpg",
      "description": "14 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Freshness Guaranteed Danish",
      "sku": 554521897,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>98</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43n12r73et1kqb10jrmmn2g.jpg",
      "description": "18 oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "On the Border Café Style Tortilla Chips",
      "sku": 578223471,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    },
    {
      "deal": "$2<sup>97</sup>",
      "imageURL": "https://cdnx.tribalfusion.com/media/9330256/img_may/p1e49fo43h1d8e1qijpq81qtq1oda19.jpg",
      "description": "48 fl. oz.",
      "buyOnlineLinkURL": "https://grocery.walmart.com/",
      "title": "Great Value Homestyle Vanilla Ice Cream",
      "sku": 571552608,
      "rollback": "true"
    }
  ]
}