//setTimeout(function(){
  //document.getElementById('app').style.visibility = "hidden";
//},6000)

 
// script to Receive the message

 
 /*
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {

    if(request.panelVisibility=="true"){
      document.getElementById('app').className ="hide";
      window._panelStatus="hide"
    }else{
      document.getElementById('app').className ="show expand show_sizes show-presentation-mode-button";
      window._panelStatus="show"
    }     
  }
);
*/
 